#include <bits/stdc++.h>
#include <iostream>
using namespace std;

#define N 3

// right, down, left, top   moves
int row[] = {0,1,0,-1};
int col[] = {1,0,-1,0};

struct Node {
    int mat[N][N];
    int x, y;
    int cost;
    int level;
    Node* parent;
};

// Hueristic
int calcCost(int current[N][N], int goal[N][N]) {
    int c=0;
    for(int i=0; i<N; i++) {
        for(int j=0; j<N; j++) {
            if(current[i][j] != goal[i][j])
                c++;
        }
    }
    return c;
}

Node* newNode(int mat[N][N], int x, int y, int newX, int newY, int level, Node* parent) {
    Node* new_node = new Node();

    for(int i=0; i<N; i++) {
        for(int j=0; j<N; j++) {
            new_node->mat[i][j] = mat[i][j];
        }
    }

    swap(new_node->mat[x][y], new_node->mat[newX][newY]);
    new_node->x = newX;
    new_node->y = newY;

    new_node->level = level;

    new_node->parent = parent;

    return new_node;
}

bool isSafe(int x, int y) {
    if(x >=0 && x < N && y >= 0 && y < N)
        return true;
    return false;
}

struct comp
{
    bool operator()(const Node* lhs, const Node* rhs) const
    {
        return (lhs->cost + lhs->level) > (rhs->cost + rhs->level);
    }
};

void printMatrix(int mat[N][N])
{
    for (int i=0; i<N; i++) {
        for (int j=0; j<N; j++)
            cout << mat[i][j] << " ";

        cout << endl;
    }
}

void printPath(Node* root) {
    if(root == NULL)
        return;
    printPath(root->parent);
    printMatrix(root->mat);
    cout << endl;
}

void solution (int initial[N][N], int x, int y, int goal[N][N]) {
    // priority queue, use min-heap
    priority_queue<Node*, vector<Node*>, comp> priq;

    Node* root = newNode(initial, x, y, x, y, 0, NULL);
    root->cost = calcCost(root->mat, goal);


    priq.push(root);

    while(!priq.empty()) {
        Node* min = priq.top();
        priq.pop();

        if(min->cost == 0) {
            printPath(min);
            return;
        }

        // do for each child for min
        for(int i=0; i<4; i++) {
            if(isSafe(min->x + row[i], min->y + col[i])) {
                Node* child = newNode(min->mat, min->x, min->y, min->x + row[i], min->y + col[i], min->level+1, min);
                child->cost = calcCost(child->mat, goal);

                priq.push(child);
            }
        }
    }
}



int main()
{
    int initial[N][N] =
    {
        {1, 2, 3},
        {5, 6, 0},
        {7, 8, 4}
    };

    int goal[N][N] =
    {
        {1, 2, 3},
        {0, 8, 6},
        {5, 7, 4}
    };

    int x = 1, y = 2;

    solution(initial, x, y, goal);

    return 0;
}
