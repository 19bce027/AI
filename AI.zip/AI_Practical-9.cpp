#include<iostream>
#include<tuple>
using namespace std;

void display(char board[3][3]){
  for(int i=0;i<3;i++){
    for(int j=0;j<3;j++){
        cout << board[i][j] << " ";
    }
    cout << "\n";
  }
  cout << "\n";
}

bool isMovesLeft(char board[3][3])
{
    for (int i = 0; i<3; i++)
        for (int j = 0; j<3; j++)
            if (board[i][j]=='_')
                return true;
    return false;
}

int evaluate(char board[3][3])
{
    for (int i = 0; i<3; i++)
    {
        if (board[i][0]==board[i][1] && board[i][1]==board[i][2])
        {
            if (board[i][0]=='x')
               return -1;
            else if (board[i][0]=='o')
               return +1;
        }
    }

    for (int j = 0; j<3; j++)
    {
        if (board[0][j]==board[1][j] && board[1][j]==board[2][j])
        {
            if (board[0][j]=='x')
                return -1;
            else if (board[0][j]=='o')
                return +1;
        }
    }

    if (board[0][0]==board[1][1] && board[1][1]==board[2][2])
    {
        if (board[0][0]=='x')
            return -1;
        else if (board[0][0]=='o')
            return +1;
    }
    if (board[0][2]==board[1][1] && board[1][1]==board[2][0])
    {
        if (board[0][2]=='x')
            return -1;
        else if (board[0][2]=='o')
            return +1;
    }

    return 0;
}
int minimax(char board[3][3], int depth, bool isMax,int alpha,int beta)
{
    int score = evaluate(board);

    if (score == 1)
        return score;

    if (score == -1)
        return score;

    if (isMovesLeft(board)==false)
        return 0;

    if (isMax)
    {
        int best = -1000;
        for (int i = 0; i<3; i++)
        {
            for (int j = 0; j<3; j++)
            {

                if (board[i][j]=='_')
                {
                    board[i][j] = 'o';
                    best = max(best,minimax(board, depth+1, !isMax,alpha,beta));
                    alpha = max(alpha, best);
                    board[i][j] = '_';
                    if (beta <= alpha){
                        return best;
                    }
                }
            }
        }
        return best;
    }

    else
    {
        int best = 1000;

        for (int i = 0; i<3; i++)
        {
            for (int j = 0; j<3; j++)
            {
                if (board[i][j]=='_')
                {
                    board[i][j] = 'x';
                    best = min(best,minimax(board, depth+1, !isMax,alpha,beta));
                    board[i][j] = '_';
                    beta = min(beta, best);

                    // Alpha Beta Pruning
                    if (beta <= alpha)
                        return best;
                }
            }
        }
        return best;
    }
}

tuple<int,int> findoptimalstate(char board[3][3])
{
    int bestVal = -1000;
    int row = -1;
    int col = -1;

    for (int i = 0; i<3; i++)
    {
        for (int j = 0; j<3; j++)
        {
            if (board[i][j]=='_')
            {
                board[i][j] = 'o';
                int moveVal = minimax(board, 0, false,-1000,1000);
                board[i][j] = '_';
                if (moveVal > bestVal)
                {
                    row = i;
                    col = j;
                    bestVal = moveVal;
                }
            }
        }
    }
    return make_tuple(row,col);
}



int main(){

 int x,y;
 char board[3][3] = {
                     {'_','_','_'},
                     {'_','_','_'},
                     {'_','_','_'}
                    };
 cout << "<< Starting State >> \n";
 display(board);
 while(isMovesLeft(board)){
    cout << "Enter Move position : ";
    cin >> x >> y;
    board[x][y] = 'x';
    display(board);
    int row,col;
    tie(row,col) = findoptimalstate(board);
    board[row][col] = 'o';
    display(board);
    int ans = evaluate(board);
    if(ans == 1){
        cout << " \n YOU LOSE!!!\n";
        return 0;
    }else if(ans == -1){
        cout << "\n You WIN!!!\n";
        return 0;
    }
 }
  cout << "\n TIE\n";



 return 0;
}
