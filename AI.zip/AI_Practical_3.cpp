#include <bits/stdc++.h>
using namespace std;
int numberofcrash(int n, vector<int> col, vector<int> prim_diag, vector<int> sec_diag, int r, int c)
{
	int ans = 0;
	ans += col[c];
	ans += prim_diag[n + c - r];
	ans += sec_diag[r + c];
	return ans;
}
bool isInlimit(int n, vector<int> col, vector<int> pd, vector<int> sd)
{
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			if (col[j] > 1 || pd[n + j - i] > 1 || sd[i + j] > 1)
				return false;
		}
	}
	return true;
}
void print(int n, vector<vector<char>> grid)
{
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
			cout << grid[i][j] << " ";
		cout << endl;
	}
}
void solve(int r, int n, vector<vector<char>> gird, vector<int> col, vector<int> prim_diag, vector<int> sec_diag)
{
	if (r == n)
	{
		if (isInlimit(n, col, prim_diag, sec_diag))
		{
			print(n, gird);
			cout << endl
				 << endl;
		}
		return;
	}
	int initial_c = 0;
	for (int i = 0; i < n; i++)
		if (gird[r][i] == 'Q')
			initial_c = i;
	set<pair<int, int>> heuristic;
	for (int i = 0; i < n; i++)
		heuristic.insert({numberofcrash(n, col, prim_diag, sec_diag, r, i), i});
	for (auto it : heuristic)
	{
		col[initial_c]--;
		prim_diag[n + initial_c - r]--;
		sec_diag[initial_c + r]--;
		gird[r][initial_c] = '.';
		col[it.second]++;
		prim_diag[n + it.second - r]++;
		sec_diag[it.second + r]++;
		gird[r][it.second] = 'Q';
		solve(r + 1, n, gird, col, prim_diag, sec_diag);
		col[it.second]--;
		prim_diag[n + it.second - r]--;
		sec_diag[it.second + r]--;
		gird[r][it.second] = '.';
		col[initial_c]++;
		prim_diag[n + initial_c - r]++;
		sec_diag[initial_c + r]++;
		gird[r][initial_c] = 'Q';
	}
}
int main()
{
	int n;
	cin >> n;
	vector<vector<char>> grid(n, vector<char>(n, '.'));
	vector<int> col(n, 0), pd(2 * n, 0), sd(2 * n, 0);
	for (int i = 0; i < n; i++)
	{
		int curr = rand();
		curr %= n;
		grid[i][curr] = 'Q';
		col[curr]++;
		pd[n + curr - i]++;
		sd[curr + i]++;

	}
	cout << "Initial Board after Genrating Random " << endl;
	for (auto i : grid)
	{
		for (auto j : i)
		{
			cout << j << " ";
		}
		cout << endl;
	}
	cout << endl;
	solve(0, n, grid, col, pd, sd);
	return 0;
}
