#include <bits/stdc++.h>
using namespace std;
void printArray(vector<vector<char>> arr)
{
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            cout << arr[i][j] << " ";
        }
        cout << endl;
    }
    cout << endl
         << endl;
}
bool check(vector<vector<char>> inti, vector<vector<char>> fin)
{
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            if (inti[i][j] != fin[i][j])
                return false;
        }
    }
    return true;
}
int main()
{
    int n = 3;
    int m = 3;
    int dx[] = {-1, 0, 1, 0};
    int dy[] = {0, 1, 0, -1};
    vector<vector<char>> intial(n, vector<char>(m));
    cout << "Enter a intial state " << endl;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            cin >> intial[i][j];
        }
    }
    cout << endl;
    cout << "Enter a Final state" << endl;
    vector<vector<char>> finalState(n, vector<char>(m));
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            cin >> finalState[i][j];
        }
    }
    cout << endl;
    queue<vector<vector<char>>> q;
    q.push(intial);
    set<vector<vector<char>>> s;
    s.insert(intial);
    while (!q.empty())
    {
        vector<vector<char>> tem = q.front();
        q.pop();
        printArray(tem);
        if (check(tem, finalState))
        {
            cout << "Final Position" << endl;
            break;
        }
        int bx, by;
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                if (tem[i][j] == '.')
                {
                    bx = i;
                    by = j;
                    break;
                }
            }
        }
        for (int i = 0; i < 4; i++)
        {
            int newX = bx + dx[i];
            int newY = by + dy[i];
            if (newX < 3 && newX >= 0 && newY < 3 && newY >= 0)
            {
                vector<vector<char>> v = tem;
                swap(v[newX][newY], v[bx][by]);
                if (s.find(v) == s.end())
                {
                    s.insert(v);
                    q.push(v);
                }
            }
        }
    }
}
